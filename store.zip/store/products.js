// Replace these with the client's real products.
// Prices are in the smallest display unit you choose; CURRENCY controls the symbol.
window.STORE = {
  name: "Store Name",
  currency: "$",
  shippingNote: "Shipping calculated at checkout."
};

window.PRODUCTS = [
  {
    id: "sample-1",
    name: "Sample Product One",
    price: 25.0,
    image: "images/sample-1.jpg",
    description: "Replace with the real product description: materials, size, what it is used for.",
    variants: ["Small", "Medium", "Large"]
  },
  {
    id: "sample-2",
    name: "Sample Product Two",
    price: 40.0,
    image: "images/sample-2.jpg",
    description: "Replace with the real product description.",
    variants: []
  },
  {
    id: "sample-3",
    name: "Sample Product Three",
    price: 18.5,
    image: "images/sample-3.jpg",
    description: "Replace with the real product description.",
    variants: ["Black", "White"]
  }
];
